#!/usr/bin/env bash
./gradlew check