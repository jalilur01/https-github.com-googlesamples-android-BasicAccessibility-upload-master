#!/usr/bin/env bash
./gradlew build
