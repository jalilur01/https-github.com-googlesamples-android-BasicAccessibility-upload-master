#!/usr/bin/env bash
./gradlew dependencies