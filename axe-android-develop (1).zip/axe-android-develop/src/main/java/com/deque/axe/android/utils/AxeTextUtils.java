package com.deque.axe.android.utils;

public class AxeTextUtils {

  public static boolean isNullOrEmpty(String string) {
    return (string == null) || (string.trim().length() <= 0);
  }

}
